import fs from 'node:fs/promises';
import { runMedia } from './media.mjs';

const ORIGIN = 'https://zinc-raven-rocket-drift.grok.me';
const TOKEN = 'md1.k7Vn4pQ2sL9wR6cH3yT8aB1eF5dJ0uM';
const pause = (ms, signal) => new Promise((resolve) => {
  if (signal?.aborted) return resolve();
  let timer;
  const finish = () => { clearTimeout(timer); signal?.removeEventListener('abort', finish); resolve(); };
  timer = setTimeout(finish, ms);
  signal?.addEventListener('abort', finish, { once: true });
});

async function call(action, body) {
  const response = await fetch(ORIGIN + '/api/media-desk', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + TOKEN },
    body: JSON.stringify({ action, ...body }),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || '网站没有接上');
  return data;
}

export async function pollWebsite({ root, label, signal }) {
  console.log('正在等待网站上的出图、出视频。不要关闭这个窗口，也不要在这里输入画面要求。');
  let warned = 0;
  while (!signal?.aborted) {
    try {
      const data = await call('poll', {});
      if (!data.job) { await pause(3000, signal); continue; }
      const job = data.job;
      console.log((job.kind === 'video' ? '出视频' : '出图') + '：' + String(job.prompt).slice(0, 40));
      try {
        const file = await runMedia({ root, label, prompt: job.prompt, kind: job.kind === 'video' ? 'video' : 'image', ratio: job.ratio });
        const bytes = await fs.readFile(file);
        const mime = job.kind === 'video' ? 'video/mp4' : 'image/png';
        await call('complete', { id: job.id, dataUrl: `data:${mime};base64,${bytes.toString('base64')}` });
        console.log('已送回网站。');
      } catch (error) {
        await call('complete', { id: job.id, error: error.message || '出图失败' }).catch(() => {});
        console.log('未完成：' + (error.message || error));
      }
    } catch (error) {
      if (Date.now() - warned > 30000) { warned = Date.now(); console.log('暂时连不上网站，会继续重试。请确认网站已经发布。'); }
      await pause(5000, signal);
    }
  }
}
