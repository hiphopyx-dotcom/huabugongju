import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {prepareProfile} from './core.mjs';

const CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const IMAGINE = 'https://grok.com/imagine';
const IMAGE_MODE = /^(图片|Image)$/;
const VIDEO_MODE = /^(视频|Video)$/;
const PROMPT_BOX = /向 Grok 提任何问题|Ask Grok anything|Ask anything|描述|Describe/i;
const SUBMIT = /^(提交|Submit|发送|Send)$/i;

async function playwright() {
  try { return await import('playwright'); }
  catch { throw Error('还没装浏览器驱动。在这个 Start 文件夹里执行：npm install playwright'); }
}

async function saveUrl(page, url, file) {
  const data = await page.evaluate(async target => {
    const res = await fetch(target);
    const bytes = new Uint8Array(await res.arrayBuffer());
    let binary = '';
    for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
    return btoa(binary);
  }, url);
  await fs.writeFile(file, Buffer.from(data, 'base64'));
}

export async function runMedia({ root, label, prompt, kind, ratio = '16:9' }) {
  if (kind !== 'image' && kind !== 'video') throw Error('只支持出图或出视频');
  const text = String(prompt || '').trim();
  if (!text || text.length > 4000) throw Error('画面要求需要 1–4000 字');
  const profile = await prepareProfile(root, label);
  const browserDir = path.join(root, 'browser', profile.id);
  await fs.mkdir(browserDir, { recursive: true, mode: 0o700 });
  const { chromium } = await playwright();
  const context = await chromium.launchPersistentContext(browserDir, {
    executablePath: CHROME,
    headless: false,
    viewport: null,
    acceptDownloads: true,
    ignoreDefaultArgs: ['--use-mock-keychain', '--password-store=basic'],
    args: ['--profile-directory=Default', '--no-first-run', '--no-default-browser-check'],
  });
  try {
    const page = context.pages()[0] || await context.newPage();
    await page.goto(IMAGINE, { waitUntil: 'domcontentloaded', timeout: 60000 });
    await page.waitForTimeout(2500);
    if (/sign-?in|login|accounts\.x\.ai/i.test(page.url())) {
      throw Error('这个账户的出图窗口还没登录。请在弹出的 Chrome 里登录 ' + label + '，登录完再选一次 8 或 9。');
    }
    const modeName = kind === 'video' ? VIDEO_MODE : IMAGE_MODE;
    const mode = page.getByRole('radio', { name: modeName }).or(page.getByRole('button', { name: modeName }));
    await mode.first().waitFor({ state: 'visible', timeout: 20000 });
    const modeButton = mode.first();
    if (await modeButton.getAttribute('aria-checked') !== 'true') await modeButton.click();
    const box = page.getByRole('textbox', { name: PROMPT_BOX }).or(page.locator('[contenteditable="true"], textarea')).first();
    await box.waitFor({ state: 'visible', timeout: 20000 });
    await box.click();
    await page.keyboard.type(text, { delay: 20 });
    const before = new Set(await page.evaluate(() => [...document.images].map(img => img.currentSrc || img.src)));
    const submit = page.getByRole('button', { name: SUBMIT }).or(page.locator('button[type="submit"]')).first();
    await submit.click();
    const folder = path.join(os.homedir(), 'Pictures', '剧爆棚出图', profile.id.slice(0, 8));
    await fs.mkdir(folder, { recursive: true });
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    if (kind === 'image') {
      const deadline = Date.now() + 180000;
      let src = '';
      while (Date.now() < deadline) {
        await page.waitForTimeout(2000);
        src = await page.evaluate(seen => {
          const fresh = [...document.images].filter(img => !seen.includes(img.currentSrc || img.src) && img.naturalWidth >= 512);
          fresh.sort((a, b) => b.naturalWidth * b.naturalHeight - a.naturalWidth * a.naturalHeight);
          return fresh[0] ? (fresh[0].currentSrc || fresh[0].src) : '';
        }, [...before]);
        if (src) break;
      }
      if (!src) throw Error('等了三分钟还没有新图');
      const file = path.join(folder, stamp + '.png');
      await saveUrl(page, src, file);
      return file;
    }
    const deadline = Date.now() + 300000;
    let src = '';
    while (Date.now() < deadline) {
      await page.waitForTimeout(3000);
      src = await page.evaluate(() => {
        const video = [...document.querySelectorAll('video')].find(node => node.currentSrc || node.src);
        return video ? (video.currentSrc || video.src) : '';
      });
      if (src && !src.startsWith('blob:')) break;
    }
    if (!src) throw Error('等了五分钟还没有视频');
    const file = path.join(folder, stamp + '.mp4');
    await saveUrl(page, src, file);
    return file;
  } finally {
    await context.close().catch(() => {});
  }
}
